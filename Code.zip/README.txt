Assignment 2

For running the code, there is just one thing to make sure that the folder named 'data' should be placed in the working directory
while running in the code as this folder contains the dataset and the names of the files should not be changed.